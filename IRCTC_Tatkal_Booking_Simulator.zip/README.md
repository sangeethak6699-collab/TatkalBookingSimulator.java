# IRCTC Tatkal Ticket Booking Simulator

An industry-style Java application simulating concurrent user ticket booking during peak Tatkal timing, demonstrating multi-threading, synchronization, custom exception handling, and GUI design.

## Project Description
When Tatkal booking opens, thousands of users try to book a limited number of train seats simultaneously. Without proper thread synchronization, multiple users can end up with the same seat (race condition). This project implements a thread-safe Tatkal simulator in Java that correctly allocates Confirmed, RAC, and Waiting-List (WL) tickets under high concurrency.

## Features
* **Multithreaded Concurrent Booking Engine:** Simulates 10+ users attempting simultaneous transactions.
* **Thread Synchronization (`synchronized` locks):** Prevents double-booking and race conditions.
* **Queue-based Waiting List:** Tracks waiting list passengers sequentially using `ConcurrentLinkedQueue`.
* **Custom Exception Handling:** Throws `SeatNotAvailableException` when full quota is reached.
* **Interactive Swing GUI:** Real-time visual dashboard showing booking output, PNR generation, and status.

## Technologies Used
* **Java (JDK 8+)**
* **Java Swing & AWT** (GUI Interface)
* **Multithreading & Synchronization**

## Setup and Running Instructions

### On Windows / Local Machine:
1. Compile the code:
   ```bash
   javac TatkalBookingSimulator.java
   ```
2. Run the application:
   ```bash
   java TatkalBookingSimulator
   ```

### On Unix / Linux Environment:
1. Open your Unix terminal.
2. Clone or download the directory:
   ```bash
   git clone <YOUR_GITHUB_REPOSITORY_LINK>
   cd irctc-tatkal-simulator
   ```
3. Compile and run:
   ```bash
   javac TatkalBookingSimulator.java
   java TatkalBookingSimulator
   ```

## Output
The application displays a graphical interface with seat status, booking logs, and real-time thread outcome visualization.

## Note
* Uses `AtomicInteger` for unique PNR generation across parallel requests.
* Fully compliant with OOP design patterns (Classes: Train, Seat, Ticket, BookingEngine).
